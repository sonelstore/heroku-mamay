[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
# Penjelasan 
 
> **Warning**:Jika ingin database terkoneksi ke MongoDb 
maka di haruskan daftar terlebih dahulu 
akun mongodb anda, Namun sc ini ada akun
Mongo gratis :


[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

```bash
web: node . --server
db: node . --db "mongodb+srv://botwa:Jxrt6KiUNOOccDuo@cluster0.dytrn2e.mongodb.net/?retryWrites=true&w=majority" --autocleartmp --restrict
```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)


>Salin Semua text di atas lalu paste kedalam file 
>Bernama Procfile
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

>Sc ini cocok bagi pemula / yang baru memulai 
>Membuat bot karena fitur nya mudah di mengerti
>dan juga gampang instalasi nya
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
 
